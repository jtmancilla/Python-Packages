from setuptools import setup

setup(name='dsp_probability',
      version='0.1',
      description='Gaussian, Binomial distributions',
      packages=['dsp_probability'],
      author='Jose A Mancilla',
      author_email = 'jt.mancilla@gmail.com',
      zip_safe=False)
